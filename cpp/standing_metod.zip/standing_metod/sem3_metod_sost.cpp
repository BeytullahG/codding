#include <iostream>
#include <fstream>
#include <string>
#include <cctype>
#include <iterator>   // для istreambuf_iterator

using namespace std;

/* ——— константы языка ——— */
const int MAX_ID_LEN = 4;        // длина идентификатора ≤ 4
const int NUM_LEN    = 5;        // знак ± + 5 цифр

/* ——— помощники ——— */
inline bool is_letter(char c){ return isalpha(static_cast<unsigned char>(c)); }
inline bool is_digit (char c){ return isdigit(static_cast<unsigned char>(c)); }
inline bool is_sign  (char c){ return c=='+' || c=='-'; }
inline bool is_op    (char c){ return c=='+'||c=='-'||c=='*'||c=='/'; }
inline bool is_space (char c){ return c==' '||c=='\n'||c=='\t'||c=='\r'; }

/* ——— печать ошибки с кареткой ——— */
void error(ofstream& out,int pos,const string& msg){
    out << '\n';
    for(int j=0;j<pos;++j) out << ' ';
    out << "^\nCompilation error: " << msg << '\n';
    exit(0);
}

int main(){
    /* ——— загружаем in.txt целиком ——— */
    ifstream in("in.txt");
    if(!in){ cerr << "Файл in.txt не найден\n"; return 1; }

    string program( (istreambuf_iterator<char>(in)),
                     istreambuf_iterator<char>() );   // весь файл
    in.close();

    ofstream out("out.txt");
    out << program << "\n\n";                         // эхо-копия

    /* ——— автомат ——— */
    int i=0, n=program.size(), state=0;
    string buf;               // собираем идентификаторы / числа
    int param_cnt = 0;        // счётчик []-пар

    while(i<=n){
        char c = (i<n) ? program[i] : '\0';           // конец ввода = '\0'
        if(is_space(c)){ ++i; continue; }

        switch(state){
        /* 0 — ждём первую букву идентификатора */
        case 0:
            if(is_letter(c)){ buf=c; state=1; ++i; }
            else if(c=='\0'){ out<<"Compilation complete\n"; return 0; }
            else error(out,i,"expected identifier");
            break;

        /* 1 — дочитываем идентификатор слева */
        case 1:
            if(is_letter(c)||is_digit(c)){
                buf+=c;
                if(buf.size()>MAX_ID_LEN) error(out,i,"identifier too long");
                ++i;
            }else if(c==':'){ state=2; buf.clear(); ++i; }
            else error(out,i,"expected ':' after identifier");
            break;

        /* 2 — ждём '=' */
        case 2:
            if(c=='='){ state=3; ++i; }
            else error(out,i,"expected '=' after ':'");
            break;

        /* 3 — первая переменная (идент / число) */
        case 3:
            if(is_letter(c)){ buf=c; state=4; ++i; }
            else if(is_sign(c)){ buf=c; state=5; ++i; }
            else error(out,i,"expected variable or number");
            break;

        /* 4 — идентификатор до < или = */
        case 4:
            if(is_letter(c)||is_digit(c)){
                buf+=c;
                if(buf.size()>MAX_ID_LEN) error(out,i,"identifier too long");
                ++i;
            }else if(c=='<'||c=='='){ state=6; ++i; buf.clear(); }
            else error(out,i,"expected '<' or '='");
            break;

        /* 5 — число (+/- + 5 цифр) */
        case 5:
            if(is_digit(c)){ buf+=c; ++i; }
            else{
                if(buf.size()!=1+NUM_LEN) error(out,i,"expected digit in number");
                while(is_space(c=program[i])) ++i;
                if(c=='<'||c=='='){ state=6; ++i; buf.clear(); }
                else error(out,i,"expected '<' or '='");
            }
            break;

        /* 6 — вторая переменная */
        case 6:
            if(is_letter(c)){ buf=c; state=7; ++i; }
            else if(is_sign(c)){ buf=c; state=8; ++i; }
            else error(out,i,"expected variable or number");
            break;

        /* 7 — идентификатор после < или = */
        case 7:
            if(is_letter(c)||is_digit(c)){
                buf+=c;
                if(buf.size()>MAX_ID_LEN) error(out,i,"identifier too long");
                ++i;
            }else if(c=='['){ state=9; ++i; param_cnt=1; }
            else error(out,i,"expected '[' after condition");
            break;

        /* 8 — число после < или = */
        case 8:
            if(is_digit(c)){ buf+=c; ++i; }
            else{
                if(buf.size()!=1+NUM_LEN) error(out,i,"expected digit in number");
                while(is_space(c=program[i])) ++i;
                if(c=='['){ state=9; ++i; param_cnt=1; }
                else error(out,i,"expected '[' after condition");
            }
            break;

        /* 9 — начало параметра */
        case 9:
            if(is_letter(c)){ buf=c; state=10; ++i; }
            else if(is_sign(c)){ buf=c; state=11; ++i; }
            else error(out,i,"expected variable or number in parameter");
            break;

        /* 10 — идентификатор внутри [] */
        case 10:
            if(is_letter(c)||is_digit(c)){
                buf+=c;
                if(buf.size()>MAX_ID_LEN) error(out,i,"identifier too long");
                ++i;
            }else if(is_op(c)){ state=12; ++i; }
            else if(c==']'){ state=13; ++i; }
            else error(out,i,"expected operator or ']'");
            break;

        /* 11 — число внутри [] */
        case 11:
            if(is_digit(c)){ buf+=c; ++i; }
            else{
                if(buf.size()!=1+NUM_LEN) error(out,i,"expected digit in number");
                if(is_op(c)){ state=12; ++i; }
                else if(c==']'){ state=13; ++i; }
                else error(out,i,"expected operator or ']'");
            }
            break;

        /* 12 — после оператора внутри [] */
        case 12:
            if(is_letter(c)){ buf=c; state=10; ++i; }
            else if(is_sign(c)){ buf=c; state=11; ++i; }
            else error(out,i,"expected variable or number");
            break;

        /* 13 — закрывающие скобки */
        case 13:
            if(param_cnt==1 && c=='['){ param_cnt=2; state=9; ++i; }
            else if(param_cnt==2 && c==']'){ state=14; ++i; }
            else error(out,i,"expected '[' or ']'");
            break;

        /* 14 — ждём ';' */
        case 14:
            if(c==';'){ state=15; ++i; }
            else error(out,i,"expected ';'");
            break;

        /* 15 — конец оператора: либо новый, либо EOF */
        case 15:
            if(is_space(c)){ ++i; }
            else if(is_letter(c)){ buf=c; state=1; ++i; }
            else if(c=='\0'){ out<<"Compilation complete\n"; return 0; }
            else error(out,i,"expected new operator or end");
            break;
        }
    }
}
